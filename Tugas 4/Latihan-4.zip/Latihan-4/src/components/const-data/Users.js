const Users = [
	{ id: 1, name: "Rayyan", fullname: "Rayyan Pratama", gender: "M" },
	{ id: 2, name: "Naila", fullname: "Naila Martiza", gender: "F" },
	{ id: 3, name: "Rhmh", fullname: "Siti Rohmah", gender: "F" },
	{ id: 4, name: "Sophie", fullname: "Sophie Makianoor", gender: "F" },
	{ id: 5, name: "Nurul", fullname: "Nurul Fikri", gender: "M" },
	{ id: 6, name: "Sandi", fullname: "Sandi Maulana", gender: "M" },
	{ id: 7, name: "Andin", fullname: "Sandrina", gender: "F" },
	{ id: 8, name: "Risma", fullname: "Risma Handayani", gender: "F" },
	{ id: 9, name: "Rayyan", fullname: "Rayyan Pratama", gender: "M" },
	{ id: 10, name: "Rayyan", fullname: "Rayyan Pratama", gender: "M" },
];

export { Users };