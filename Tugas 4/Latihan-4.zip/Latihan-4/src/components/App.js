import InstagramUI from './src/components/Instagram/InstagramUI';

export default function App() {
  return <InstagramUI />;
}

