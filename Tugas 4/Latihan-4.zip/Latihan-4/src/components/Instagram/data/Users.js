const Users = [
	{ id: 1, name: "ryn_prtm30",  gender: "M", imageUrl: 'https://www.acehardware.co.id/files/uploads/inspirationarticle/thumb_image/2022/Oct/11/mainimagecaramenjinakkankucingwebp-770x770.webp',
	caption: 'Kucing-Ku yang manis ' },
	{ id: 2, name: "nailamrtzaa",  gender: "F" , imageUrl: 'https://i.pinimg.com/originals/49/93/b2/4993b28c18b9ac5c342b1da4c472706f.jpg',
	caption: 'P.S. I love you',},
	{ id: 3, name: "its_rhmh", gender: "F" , imageUrl: 'https://i.pinimg.com/564x/79/5f/40/795f40a63d33b1d90b876511e234fdab.jpg',
	caption: 'My-Husband luvluv'},
	{ id: 4, name: "sophiemknr", gender: "F", imageUrl: 'https://i.pinimg.com/564x/53/20/38/532038421c597b62bb142f6b59782f12.jpg',
	caption: 'Daddy Home' },
	{ id: 5, name: "fikryyn", gender: "M" , imageUrl: 'https://kabarjombang.com/wp-content/uploads/2022/11/2802870403.png',
	caption: 'raaaaawrrrrrr'},
	{ id: 6, name: "sandy_m",  gender: "M" , imageUrl: 'https://i.pinimg.com/564x/48/98/df/4898dfd81e4ded34001b436663853af4.jpg',
	caption: 'Hooooottttt'},
	{ id: 7, name: "unt.0ward", gender: "F" , imageUrl: 'https://i.pinimg.com/564x/6a/c3/7c/6ac37ca4661721ff2e0ae61bcd33f594.jpg',
	caption: 'Sedang tergila-gila sama F1'},
	{ id: 8, name: "rismahandd", gender: "F" , imageUrl: 'https://i.pinimg.com/736x/72/54/64/72546420ecbc575bba00902ce889b6b8.jpg',
	caption: 'Beauty'},
	{ id: 9, name: "Rayyan",  gender: "M" , imageUrl: 'https://marketplace.canva.com/EAELwoZt0kA/1/0/1600w/canva-postingan-instagram-berita-pertanian-hijau-dan-putih-jPfj65ePMqw.jpg',
	caption: 'Berita hari ini'},
	{ id: 10, name: "Rayyan", gender: "M" , imageUrl: 'https://marketplace.canva.com/EAELwoZt0kA/1/0/1600w/canva-postingan-instagram-berita-pertanian-hijau-dan-putih-jPfj65ePMqw.jpg',
	caption: 'Berita hari ini',},
];

export { Users };